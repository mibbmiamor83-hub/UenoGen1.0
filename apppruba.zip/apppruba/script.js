window.addEventListener('load', () => {
    setTimeout(() => {
        document.getElementById('splash-screen').style.display = 'none';
        document.getElementById('app-content').style.display = 'flex';
    }, 4000);
});

function updateClock() {
    const now = new Date();
    document.getElementById('current-time').innerText = 
        String(now.getHours()).padStart(2, '0') + ":" + String(now.getMinutes()).padStart(2, '0');
}
setInterval(updateClock, 1000);
updateClock();

const randomBalance = 170538;
document.getElementById('main-balance').innerText = randomBalance.toLocaleString('es-PY');

const paraguayanNames = [
    "Jorge Hernández", "Mirta Graciela Garay", "Maria Veronica Nunez Fernandez", 
    "Valeria Yohana Irala Quintana", "Gaona Acosta, Alicia", "Carlos Diaz", 
    "Maribel Mendieta", "Ariel Benitez", "Leticia Quintana", "Gustavo Pereira"
];

function addMovement(name, amount, date, isPositive) {
    const txList = document.getElementById('txList');
    const color = isPositive ? "#00E676" : "#212121";
    const sign = isPositive ? "+ " : "- ";
    
    const html = `
        <div style="display:flex; justify-content:space-between; padding:18px 0; border-bottom:1px solid #F8F8F8;">
            <div>
                <p style="font-size:14px; font-weight:600; color:#212121; margin-bottom:2px;">Transferencias</p>
                <p style="font-size:13.5px; color:#8D8D99; font-weight:500;">${name}</p>
            </div>
            <div style="text-align:right;">
                <p style="font-size:14.5px; font-weight:800; color:${color};">${sign}Gs. ${amount}</p>
                <p style="font-size:12px; color:#8D8D99; font-weight:600; margin-top:2px;">${date}</p>
            </div>
        </div>`;
    txList.insertAdjacentHTML('afterbegin', html);
}

function initHistory() {
    const data = [
        {n: "Gaona Acosta, Alicia", a: "37.000", d: "Jueves", p: true},
        {n: "Valeria Yohana Irala Quintana", a: "15.000", d: "Sábado", p: false},
        {n: "Maria Veronica Nunez Fernandez", a: "37.000", d: "Sábado", p: true},
        {n: "Mirta Graciela Garay", a: "15.000", d: "Hoy", p: false},
        {n: "Jorge Hernández", a: "25.000", d: "Hoy", p: true}
    ];
    data.forEach(item => addMovement(item.n, item.a, item.d, item.p));
}
initHistory();

function openModal() {
    document.getElementById('mainModal').style.display = 'flex';
    document.getElementById('stepForm').style.display = 'block';
    document.getElementById('stepReceipt').style.display = 'none';
}

function closeModal() {
    document.getElementById('mainModal').style.display = 'none';
}

function generateReceipt() {
    const receiver = document.getElementById('inReceiver').value || "Nancy";
    const acc = document.getElementById('inAcc').value || "62278712";
    const bank = document.getElementById('inBank').value;
    const amount = document.getElementById('inAmount').value || "28000";
    const sender = document.getElementById('inSender').value;

    const formattedAmt = parseInt(amount).toLocaleString('es-PY');

    document.getElementById('outSender').innerText = sender;
    document.getElementById('outReceiver').innerText = receiver;
    document.getElementById('outAcc').innerText = acc;
    document.getElementById('outBank').innerText = bank;
    document.getElementById('outAmount').innerText = formattedAmt;
    
    document.getElementById('outID').innerText = "2603" + Math.floor(Math.random() * 90000000);
    const now = new Date();
    const dateStr = String(now.getDate()).padStart(2, '0') + "/" + String(now.getMonth() + 1).padStart(2, '0') + "/" + now.getFullYear();
    const timeStr = String(now.getHours()).padStart(2, '0') + ":" + String(now.getMinutes()).padStart(2, '0');
    document.getElementById('outDate').innerText = `${dateStr} a las ${timeStr} h`;

    addMovement(receiver, formattedAmt, 'Hoy', false);
    document.getElementById('stepForm').style.display = 'none';
    document.getElementById('stepReceipt').style.display = 'block';
}
